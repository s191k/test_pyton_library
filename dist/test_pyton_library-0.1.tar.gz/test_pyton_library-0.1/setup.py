from setuptools import setup, find_packages

setup(name='test_pyton_library',
      version='0.1',
      author='temp',
      author_email='temp',
      description='temp',
      packages=find_packages(),
      )